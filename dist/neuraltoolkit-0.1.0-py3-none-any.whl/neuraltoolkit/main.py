# import pandas as pd

# def createDF(list):
#     df = pd.DataFrame(list)
#     return df

def func(x):
    print(f'func {x} = {x}')
    return x