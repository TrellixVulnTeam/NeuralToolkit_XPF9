import pandas as pd

def multi(x, y):
    return x*y