from . import search
# from ipywidgets import interact, interactive, fixed, interact_manual
# from IPython.display import display

class NeuralDataSet:
    data = None
    path = None

    def __init__(self, path):
        self.path
        self.data = search(path)