from pedros import LocalPopulation
import pandas as pd


class NeuralDataSet:

  def __init__():
    return